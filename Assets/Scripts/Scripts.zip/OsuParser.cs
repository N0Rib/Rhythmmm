// OsuParser.cs
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class OsuParser
{
    public float BPM = 120f;
    public float Offset = 0f;
    public List<NoteData> Notes { get; private set; }

    public List<NoteData> ParseTxtFile(string filePath)
    {
        Notes = new List<NoteData>();

        if (!File.Exists(filePath))
        {
            Debug.LogError($"File not found: {filePath}");
            return Notes;
        }

        string[] lines = File.ReadAllLines(filePath);

        bool isHitObjectsSection = false;
        bool isTimingPointsSection = false;

        foreach (var line in lines)
        {
            string trimmedLine = line.Trim();

            if (trimmedLine == "[HitObjects]")
            {
                isHitObjectsSection = true;
                isTimingPointsSection = false;
                continue;
            }

            if (trimmedLine == "[TimingPoints]")
            {
                isTimingPointsSection = true;
                isHitObjectsSection = false;
                continue;
            }

            if (isHitObjectsSection)
            {
                ParseHitObject(trimmedLine);
            }

            if (isTimingPointsSection)
            {
                ParseTimingPoint(trimmedLine);
            }
        }

        Debug.Log($"Parsed {Notes.Count} notes from file: {filePath}, BPM: {BPM}, Offset: {Offset}");
        return Notes;
    }

    void ParseHitObject(string line)
    {
        string[] parts = line.Split(',');
        if (parts.Length < 5) return;

        int x = int.Parse(parts[0]);
        float time = float.Parse(parts[2]) / 1000f;
        int type = int.Parse(parts[3]);

        if ((type & 1) > 0)
        {
            Notes.Add(new NoteData
            {
                Time = time,
                Lane = ConvertToLane(x),
                IsLongNote = false
            });
        }
        else if ((type & 128) > 0)
        {
            if (parts.Length > 5)
            {
                string[] extraData = parts[5].Split(':');
                float endTime = float.Parse(extraData[0]) / 1000f;

                Notes.Add(new NoteData
                {
                    Time = time,
                    EndTime = endTime,
                    Lane = ConvertToLane(x),
                    IsLongNote = true
                });
            }
        }
    }

    void ParseTimingPoint(string line)
    {
        var parts = line.Split(',');
        if (parts.Length > 1)
        {
            float beatLengthMs = float.Parse(parts[1]);
            if (beatLengthMs > 0)
            {
                BPM = 60000f / beatLengthMs;
            }
        }
    }

    int ConvertToLane(int x)
    {
        if (x < 128) return 0;
        if (x < 256) return 1;
        if (x < 384) return 2;
        return 3;
    }
}
