// NoteData.cs
[System.Serializable]
public class NoteData
{
    public float Time;
    public float EndTime;
    public bool IsLongNote;
    public int Lane;
}
