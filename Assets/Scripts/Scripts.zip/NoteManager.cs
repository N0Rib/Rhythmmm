// NoteManager.cs
using UnityEngine;
using System.Collections.Generic;

public class NoteManager : MonoBehaviour
{
    public ObjectPool objectPool;
    public Transform[] lanes;
    public Transform judgementLine;
    public AudioSource audioSource;
    public JudgeManager judgeManager;

    public float BPM = 120f;
    public float globalOffset = 0f;
    public bool useFixedSpeed = false;

    public float fixedSpeed = 5f;
    public float approachTime = 2f;

    private Queue<NoteData> noteQueue = new Queue<NoteData>();
    private Dictionary<int, List<float>> laneNoteTimes = new Dictionary<int, List<float>>();

    void Start()
    {
        int laneCount = lanes.Length;
        for (int i = 0; i < laneCount; i++)
        {
            laneNoteTimes[i] = new List<float>();
        }

        if (objectPool == null)
        {
            Debug.LogError("ObjectPool is not assigned in the NoteManager.");
        }
    }

    public void LoadNotes(List<NoteData> notes, float parsedBPM, float parsedOffset)
    {
        BPM = parsedBPM;
        globalOffset = parsedOffset;

        foreach (var note in notes)
        {
            noteQueue.Enqueue(note);
        }

        int shortNoteCount = 0;
        int longNoteCount = 0;

        foreach (var note in notes)
        {
            if (note.IsLongNote)
                longNoteCount++;
            else
                shortNoteCount++;
        }

        if (objectPool != null)
        {
            objectPool.InitializePools(shortNoteCount, longNoteCount);
            Debug.Log($"Initialized ObjectPool with ShortNotes: {shortNoteCount}, LongNotes: {longNoteCount}");
        }
        else
        {
            Debug.LogError("ObjectPool is not assigned in the NoteManager!");
        }
    }

    void Update()
    {
        if (noteQueue.Count > 0 && objectPool != null)
        {
            float currentTime = audioSource.time;
            NoteData nextNote = noteQueue.Peek();
            float targetTime = nextNote.Time + globalOffset;
            float distance = Mathf.Abs(lanes[nextNote.Lane].position.y - judgementLine.position.y);

            float actualApproachTime = useFixedSpeed ? (distance / fixedSpeed) : approachTime;
            float spawnTime = targetTime - actualApproachTime;

            if (currentTime >= spawnTime)
            {
                noteQueue.Dequeue();
                CreateNote(nextNote, distance, actualApproachTime);
            }
        }
    }

    void CreateNote(NoteData noteData, float distance, float actualApproachTime)
    {
        Transform spawnPoint = lanes[noteData.Lane];
        if (spawnPoint == null || judgeManager == null || audioSource == null)
        {
            Debug.LogError("Missing references! Please assign all required prefabs and managers.");
            return;
        }

        Vector3 spawnPos = spawnPoint.position;
        float checkTime = noteData.Time;
        bool tooClose = false;
        foreach (var t in laneNoteTimes[noteData.Lane])
        {
            if (Mathf.Abs(t - checkTime) < 0.1f)
            {
                tooClose = true;
                break;
            }
        }
        if (tooClose)
            spawnPos.x += 0.1f;

        laneNoteTimes[noteData.Lane].Add(checkTime);

        GameObject noteObj;
        if (noteData.IsLongNote)
        {
            noteObj = objectPool.SpawnLongNote(spawnPos, Quaternion.identity);
        }
        else
        {
            noteObj = objectPool.SpawnShortNote(spawnPos, Quaternion.identity);
        }

        if (noteObj == null)
        {
            Debug.LogError($"Failed to spawn note of type {(noteData.IsLongNote ? "LongNote" : "ShortNote")}.");
            return;
        }

        NoteController controller = noteObj.GetComponent<NoteController>();
        if (controller == null)
        {
            Debug.LogError("NoteController is missing on the prefab!");
            noteObj.SetActive(false);
            return;
        }

        controller.useFixedSpeed = useFixedSpeed;
        controller.fixedSpeed = fixedSpeed;
        controller.Initialize(noteData, spawnPoint, judgementLine, audioSource, actualApproachTime, globalOffset, distance);

        judgeManager.AddNoteToLane(noteData.Lane, controller);
    }
}
