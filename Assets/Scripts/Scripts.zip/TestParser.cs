// TestParser.cs
using System.Collections.Generic;
using UnityEngine;

public class TestParser : MonoBehaviour
{
    public string noteFilePath;
    public NoteManager noteManager;
    public ObjectPool objectPool;
    public AudioSource audioSource;

    void Start()
    {
        if (!string.IsNullOrEmpty(noteFilePath))
        {
            LoadAndCreateNotes(noteFilePath);
        }
        else
        {
            Debug.LogError("Note file path is not set!");
        }

        if (audioSource != null && audioSource.clip != null)
        {
            audioSource.Play();
            Debug.Log($"Playing music: {audioSource.clip.name}");
        }
        else
        {
            Debug.LogError("AudioSource or Audio Clip is not set!");
        }
    }

    void LoadAndCreateNotes(string filePath)
    {
        OsuParser parser = new OsuParser();
        List<NoteData> notes = parser.ParseTxtFile(filePath);

        if (notes != null && notes.Count > 0)
        {
            int shortNoteCount = 0;
            int longNoteCount = 0;

            foreach (var note in notes)
            {
                if (note.IsLongNote)
                    longNoteCount++;
                else
                    shortNoteCount++;
            }

            if (objectPool != null)
            {
                objectPool.InitializePools(shortNoteCount, longNoteCount);
                Debug.Log($"Initialized ObjectPool with ShortNotes: {shortNoteCount}, LongNotes: {longNoteCount}");
            }
            else
            {
                Debug.LogError("ObjectPool reference is not set in TestParser!");
            }

            noteManager.LoadNotes(notes, parser.BPM, parser.Offset);
            Debug.Log($"Loaded {notes.Count} notes from {filePath}");
        }
        else
        {
            Debug.LogError($"Failed to parse notes or no notes found in file: {filePath}");
        }
    }
}
