// JudgeManager.cs
using UnityEngine;
using System.Collections.Generic;

public class JudgeManager : MonoBehaviour
{
    public AudioSource audioSource;

    public float perfectWindow = 0.05f;
    public float greatWindow = 0.1f;
    public float goodWindow = 0.2f;

    private List<NoteController>[] laneNotes;
    private LongNoteController[] holdingLongNotes;

    void Start()
    {
        int laneCount = 4;
        laneNotes = new List<NoteController>[laneCount];
        for (int i = 0; i < laneCount; i++)
        {
            laneNotes[i] = new List<NoteController>();
        }

        holdingLongNotes = new LongNoteController[laneCount];

        InputManager.OnLaneHit += OnLaneHitReceived;
    }

    void OnDestroy()
    {
        InputManager.OnLaneHit -= OnLaneHitReceived;
    }

    public void AddNoteToLane(int lane, NoteController note)
    {
        laneNotes[lane].Add(note);
    }

    void Update()
    {
        float currentTime = audioSource.time;

        for (int lane = 0; lane < holdingLongNotes.Length; lane++)
        {
            var ln = holdingLongNotes[lane];
            if (ln == null) continue;

            bool isHoldingKey = InputManager.IsLaneKeyHolding(lane);

            if (!isHoldingKey && !ln.IsHoldFailed())
            {
                ln.SetHoldFailed();
                ShowJudgement("Miss");
            }

            if (ln.currentState == LongNoteController.LongNoteState.Missed ||
                ln.currentState == LongNoteController.LongNoteState.Ended)
            {
                laneNotes[lane].Remove(ln);
                holdingLongNotes[lane] = null;
            }
        }

        // �ð��� ������ ��Ʈ�� �� �������� �� "Miss" ����
        CheckForMissedNotes(currentTime);
    }

    private void OnLaneHitReceived(int lane)
    {
        float currentTime = audioSource.time;
        NoteController targetNote = FindJudgeableNote(lane, currentTime);

        if (targetNote == null)
        {
            ShowJudgement("Miss");
            return;
        }

        float timeDiff = Mathf.Abs((targetNote.noteData.Time + targetNote.GetGlobalOffset()) - currentTime);

        string result;
        if (timeDiff <= perfectWindow)
            result = "Perfect";
        else if (timeDiff <= greatWindow)
            result = "Great";
        else if (timeDiff <= goodWindow)
            result = "Good";
        else
            result = "Miss";

        ShowJudgement(result);

        LongNoteController ln = targetNote as LongNoteController;
        if (ln != null)
        {
            if (ln.currentState == LongNoteController.LongNoteState.NotStarted)
            {
                ln.StartHit();
                holdingLongNotes[lane] = ln;
            }
            else if (ln.currentState == LongNoteController.LongNoteState.Started)
            {
                if (currentTime >= ln.GetEndTime() - goodWindow && currentTime <= ln.GetEndTime() + goodWindow)
                {
                    ln.EndHit();
                }
                else
                {
                    ShowJudgement("Miss");
                }
            }
        }
        else
        {
            laneNotes[lane].Remove(targetNote);
            targetNote.ReturnToPool();
        }
    }

    NoteController FindJudgeableNote(int lane, float currentTime)
    {
        NoteController candidate = null;
        float minDiff = float.MaxValue;

        foreach (var note in laneNotes[lane])
        {
            float targetTime = note.noteData.Time + note.GetGlobalOffset();
            float diff = Mathf.Abs(targetTime - currentTime);
            if (diff < minDiff && diff <= goodWindow)
            {
                minDiff = diff;
                candidate = note;
            }
        }

        return candidate;
    }

    void ShowJudgement(string result)
    {
        if (JudgementManager.Instance != null)
        {
            JudgementManager.Instance.ShowJudgement(result);
        }
        else
        {
            Debug.LogError("JudgementManager �ν��Ͻ��� �������� �ʽ��ϴ�.");
        }
    }

    /// <summary>
    /// Ư�� �ð��� ������ ��Ʈ�� ���� ��� "Miss" ������ �߻���Ű�� �޼���
    /// </summary>
    /// <param name="currentTime">���� ����� �ð�</param>
    void CheckForMissedNotes(float currentTime)
    {
        for (int lane = 0; lane < laneNotes.Length; lane++)
        {
            for (int i = laneNotes[lane].Count - 1; i >= 0; i--)
            {
                NoteController note = laneNotes[lane][i];
                float noteTime = note.noteData.Time + note.GetGlobalOffset();
                if (currentTime > noteTime + goodWindow)
                {
                    // Miss ���� �߻�
                    ShowJudgement("Miss");
                    laneNotes[lane].RemoveAt(i);
                    note.ReturnToPool();
                }
            }
        }
    }
}
