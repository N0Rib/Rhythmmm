// IPooledObject.cs
public interface IPooledObject
{
    void OnObjectSpawn();
}
